<?php
/**
 * Plugin Name: Menú Bares
 * Description: Shortcodes y lógica para mostrar menús de bares.
 * Version: 1.0
 * Author: desarrolloydisenio.com.ar
 */

if (!defined('ABSPATH')) exit; // Seguridad: evitar acceso directo

// Shortcode principal
function menu_dinamico_bares_shortcode() {
    global $wpdb;

    $slug = trim($_SERVER['REQUEST_URI'], '/');
    $slug_parts = explode('/', $slug);
    $slug_cliente = isset($slug_parts[1]) ? sanitize_text_field($slug_parts[1]) : '';

    if (!$slug_cliente) return "<p>Bar no identificado.</p>";

    $cliente = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, nombre FROM aa_clientes_autorizados WHERE slug = %s",
            $slug_cliente
        )
    );

    if (!$cliente) return "<p>Menú no disponible para este bar.</p>";

    $cliente_id = $cliente->id;
    $categorias = $wpdb->get_results("SELECT * FROM aa_menu_categorias ORDER BY orden ASC");

    $salida = "<div class='menu-bares'>";
    $salida .= "<h1 class='titulo-menu'>Menú de " . esc_html($cliente->nombre) . "</h1>";

    foreach ($categorias as $categoria) {
        $productos = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM aa_menu_productos WHERE cliente_id = %d AND categoria_id = %d ORDER BY orden ASC",
                $cliente_id,
                $categoria->id
            )
        );

        if (!$productos) continue;

        $salida .= "<h2 class='categoria'>" . esc_html($categoria->nombre) . "</h2>";
        $salida .= "<ul class='productos'>";
        foreach ($productos as $producto) {
            $salida .= "<li class='producto'>";
            $salida .= "<strong>" . esc_html($producto->nombre) . "</strong>";
            $salida .= " - $" . number_format($producto->precio, 2);
            $salida .= "</li>";
        }
        $salida .= "</ul>";
    }

    $salida .= "</div>";

    return $salida;
}

// 🔧 Registro del shortcode
add_shortcode('menu_bares', 'menu_dinamico_bares_shortcode');
